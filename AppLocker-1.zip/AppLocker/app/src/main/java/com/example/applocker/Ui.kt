package com.example.applocker

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

object C {
    val bg = Color(0xFF0E1120)
    val card = Color(0xFF181C31)
    val card2 = Color(0xFF232844)
    val primary = Color(0xFF7C83FF)
    val deep = Color(0xFF4F46E5)
    val onPrimary = Color(0xFF0E1120)
    val text = Color(0xFFEDEFFF)
    val sub = Color(0xFF9AA0C3)
    val warn = Color(0xFFFFB86B)
}

@Composable
fun LockerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.primary,
            onPrimary = C.onPrimary,
            background = C.bg,
            surface = C.card,
            onSurface = C.text,
            onBackground = C.text,
            surfaceVariant = C.card2,
            onSurfaceVariant = C.sub
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}

fun fmt(ms: Long): String {
    val s = (ms.coerceAtLeast(0)) / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}
