package com.example.applocker

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BlockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { LockerTheme { Block() } }
    }

    @Composable
    private fun Block() {
        val until = Store.until(this)
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(until))
        var remaining by remember { mutableLongStateOf(until - System.currentTimeMillis()) }
        LaunchedEffect(Unit) {
            while (remaining > 0) {
                remaining = until - System.currentTimeMillis()
                delay(1000)
            }
        }
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF1B1F4A), C.bg)))
                .statusBarsPadding().navigationBarsPadding().padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(128.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(C.deep, C.primary))),
                    contentAlignment = Alignment.Center
                ) { Text("🔒", fontSize = 56.sp) }
                Spacer(Modifier.height(28.dp))
                Text("هذا التطبيق مقفل", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = C.text)
                Spacer(Modifier.height(8.dp))
                Text(
                    "ستتمكن من فتحه الساعة $time",
                    fontSize = 16.sp, color = C.sub, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(C.card2)
                        .padding(horizontal = 28.dp, vertical = 14.dp)
                ) {
                    Text(fmt(remaining), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = C.primary)
                }
                Spacer(Modifier.height(36.dp))
                Button(
                    onClick = { goHome() },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.primary, contentColor = C.onPrimary)
                ) { Text("العودة للرئيسية", fontWeight = FontWeight.Bold) }
            }
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()
}
