package com.example.applocker

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("locker", Context.MODE_PRIVATE)

    fun apps(c: Context): Set<String> = p(c).getStringSet("apps", emptySet())!!.toSet()
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun active(c: Context): Boolean = System.currentTimeMillis() < until(c)

    fun start(c: Context, apps: Set<String>, minutes: Int) {
        p(c).edit()
            .putStringSet("apps", apps)
            .putLong("until", System.currentTimeMillis() + minutes * 60_000L)
            .apply()
    }
}
