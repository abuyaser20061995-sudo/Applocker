package com.example.applocker

import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay

data class AppItem(val pkg: String, val name: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {

    private var serviceOn by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent { LockerTheme { Screen() } }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        serviceOn = enabled.contains("$packageName/")
    }

    @Composable
    private fun Screen() {
        val pm = packageManager
        val apps = remember {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .map {
                    AppItem(
                        it.activityInfo.packageName,
                        it.loadLabel(pm).toString(),
                        it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
                    )
                }
                .sortedBy { it.name.lowercase() }
        }
        val selected = remember { mutableStateListOf<String>() }
        var minutes by remember { mutableIntStateOf(30) }
        var query by remember { mutableStateOf("") }
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        var locks by remember { mutableStateOf(Store.locks(this@MainActivity)) }

        LaunchedEffect(Unit) {
            while (true) {
                now = System.currentTimeMillis()
                locks = Store.locks(this@MainActivity)
                delay(1000)
            }
        }

        val lockedApps = apps.filter { it.pkg in locks }.sortedBy { locks[it.pkg] ?: 0L }
        val freeApps = apps.filter {
            it.pkg !in locks && it.name.contains(query.trim(), ignoreCase = true)
        }

        Column(Modifier.fillMaxSize().background(C.bg)) {
            Header()

            LazyColumn(
                Modifier.weight(1f).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                if (!serviceOn) {
                    item {
                        WarnCard()
                        Spacer(Modifier.height(12.dp))
                    }
                }

                if (lockedApps.isNotEmpty()) {
                    item { SectionTitle("المقفلة الآن (${lockedApps.size})") }
                    items(lockedApps, key = { "L" + it.pkg }) { app ->
                        LockedRow(app, (locks[app.pkg] ?: 0L) - now)
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }

                item { DurationCard(minutes) { minutes = it } }
                item {
                    Spacer(Modifier.height(12.dp))
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("ابحث عن تطبيق") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = C.card,
                            unfocusedContainerColor = C.card,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                }
                item { SectionTitle("اختر التطبيقات (${selected.size})") }

                items(freeApps, key = { "A" + it.pkg }) { app ->
                    val on = app.pkg in selected
                    AppRow(app, on) {
                        if (on) selected.remove(app.pkg) else selected.add(app.pkg)
                    }
                }
            }

            Box(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding()) {
                Button(
                    onClick = {
                        Store.lock(this@MainActivity, selected.toList(), minutes)
                        selected.clear()
                        locks = Store.locks(this@MainActivity)
                    },
                    enabled = serviceOn && selected.isNotEmpty(),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = C.primary,
                        contentColor = C.onPrimary,
                        disabledContainerColor = C.card2,
                        disabledContentColor = C.sub
                    )
                ) {
                    Text(
                        if (selected.isEmpty()) "اختر تطبيقاً لقفله" else "قفل المحدد (${selected.size})",
                        fontSize = 17.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    @Composable
    private fun SectionTitle(text: String) {
        Text(
            text, color = C.sub, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 6.dp)
        )
    }

    @Composable
    private fun AppRow(app: AppItem, on: Boolean, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (on) C.card2 else C.card)
                .clickable { onClick() }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Text(app.name, Modifier.weight(1f), color = C.text, fontSize = 16.sp)
            Switch(
                checked = on,
                onCheckedChange = null,
                colors = SwitchDefaults.colors(
                    checkedTrackColor = C.primary,
                    checkedThumbColor = C.onPrimary
                )
            )
        }
    }

    @Composable
    private fun LockedRow(app: AppItem, remaining: Long) {
        Row(
            Modifier.fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF2A2F66), C.card2)))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = null,
                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Text(app.name, Modifier.weight(1f), color = C.text, fontSize = 16.sp)
            Box(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(C.primary.copy(alpha = 0.18f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("🔒 " + fmt(remaining), color = C.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }

    @Composable
    private fun Header() {
        Box(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.linearGradient(listOf(C.deep, C.primary)))
                .statusBarsPadding()
                .padding(horizontal = 24.dp, vertical = 22.dp)
        ) {
            Column {
                Text("🔒 قفل التطبيقات", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Text("ركّز أكثر وابتعد عن المشتتات", fontSize = 14.sp, color = Color.White.copy(alpha = 0.85f))
            }
        }
    }

    @Composable
    private fun WarnCard() {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(C.warn.copy(alpha = 0.14f))
                .padding(16.dp)
        ) {
            Text(
                "فعّل خدمة «قفل التطبيقات» من إعدادات إمكانية الوصول ليعمل القفل.",
                color = C.warn, fontSize = 14.sp
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = C.warn, contentColor = Color.Black)
            ) { Text("فتح الإعدادات", fontWeight = FontWeight.Bold) }
        }
    }

    @Composable
    private fun DurationCard(minutes: Int, onPick: (Int) -> Unit) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(C.card)
                .padding(16.dp)
        ) {
            Text("مدة القفل للتطبيقات المحددة", color = C.sub, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15 to "15 د", 30 to "30 د", 60 to "ساعة", 120 to "ساعتان").forEach { (m, label) ->
                    val sel = minutes == m
                    Box(
                        Modifier.weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) C.primary else C.card2)
                            .clickable { onPick(m) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            color = if (sel) C.onPrimary else C.text,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
