package com.example.applocker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var serviceOn by mutableStateOf(false)
    private var lockActive by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Screen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        serviceOn = enabled.contains("$packageName/")
        lockActive = Store.active(this)
    }

    @Composable
    private fun Screen() {
        val pm = packageManager
        val apps = remember {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .filter { it.first != packageName }
                .distinctBy { it.first }
                .sortedBy { it.second }
        }
        val selected = remember { mutableStateListOf<String>().apply { addAll(Store.apps(this@MainActivity)) } }
        var minutes by remember { mutableIntStateOf(30) }

        Column(Modifier.fillMaxSize().padding(16.dp).statusBarsPadding()) {
            Text("قفل التطبيقات", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))

            if (!serviceOn) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("فعّل خدمة «قفل التطبيقات» من إعدادات إمكانية الوصول ليعمل القفل.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }) { Text("فتح الإعدادات") }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            if (lockActive) {
                val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(Store.until(this@MainActivity)))
                Text("🔒 القفل مفعّل حتى الساعة $t", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
            } else {
                Text("المدة (بالدقائق):")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 60, 120).forEach { m ->
                        FilterChip(
                            selected = minutes == m,
                            onClick = { minutes = m },
                            label = { Text("$m") }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            Text("اختر التطبيقات:")
            LazyColumn(Modifier.weight(1f)) {
                items(apps) { (pkg, name) ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = !lockActive) {
                                if (pkg in selected) selected.remove(pkg) else selected.add(pkg)
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = pkg in selected,
                            enabled = !lockActive,
                            onCheckedChange = null
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(name, Modifier.padding(vertical = 12.dp))
                    }
                }
            }

            Button(
                onClick = {
                    Store.start(this@MainActivity, selected.toSet(), minutes)
                    lockActive = true
                },
                enabled = serviceOn && !lockActive && selected.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("ابدأ القفل") }
        }
    }
}
