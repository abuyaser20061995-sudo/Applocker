package com.example.applocker

import android.content.Context

/** لكل تطبيق وقت انتهاء مستقل: pkg -> وقت الانتهاء (ms) */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("locker2", Context.MODE_PRIVATE)

    private fun read(c: Context): Map<String, Long> {
        val m = mutableMapOf<String, Long>()
        for (entry in p(c).getStringSet("locks", emptySet())!!) {
            val i = entry.lastIndexOf('|')
            if (i > 0) {
                val t = entry.substring(i + 1).toLongOrNull()
                if (t != null) m[entry.substring(0, i)] = t
            }
        }
        return m
    }

    private fun write(c: Context, m: Map<String, Long>) {
        p(c).edit().putStringSet("locks", m.map { "${it.key}|${it.value}" }.toSet()).apply()
    }

    /** الأقفال السارية فقط (ويُنظّف المنتهي) */
    fun locks(c: Context): Map<String, Long> {
        val now = System.currentTimeMillis()
        val all = read(c)
        val live = all.filter { it.value > now }
        if (live.size != all.size) write(c, live)
        return live
    }

    fun until(c: Context, pkg: String): Long = locks(c)[pkg] ?: 0L

    fun isLocked(c: Context, pkg: String): Boolean = until(c, pkg) > System.currentTimeMillis()

    /** يقفل كل تطبيق بمؤقته الخاص؛ لا يغيّر مؤقت تطبيق مقفل مسبقاً */
    fun lock(c: Context, pkgs: Collection<String>, minutes: Int) {
        val m = locks(c).toMutableMap()
        val end = System.currentTimeMillis() + minutes * 60_000L
        for (pkg in pkgs) if (!m.containsKey(pkg)) m[pkg] = end
        write(c, m)
    }
}
